const studentsData = [
    { name : 'Hamazasp', surname : "Grigoryan" },
    { name : 'Valod', surname : "Vardevanyan" },
    { name : 'Grisha', surname : "Aghaxanyan" },
    { name : 'Shprot', surname : "Ani Tovmasyan" }
];

const booksData = [
    { title : 'Giqor', author: "Hovhannes Tumanyan" },
    { title : 'Samvel', author: "Raffi" },
    { title : 'Heqiatner' ,author: "Ghazaros Axayan" },
    { title : 'Erker', author: "Siamanto" },
    { title : 'Arevi Erkir', author: "Hovhannes Shiraz" },
    { title : 'Erkir Nairi', author : "Exishe Charents"}
];

module.exports = { studentsData, booksData };